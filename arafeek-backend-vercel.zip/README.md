# خادم النشر الاجتماعي — نسخة Vercel (3 ملفات)

الملفات: `api/index.js` و`vercel.json` و`package.json`. لا تُنشئ مجلدات أخرى.

## الرفع من الهاتف
1. GitHub → مستودعك → Add file → **Create new file**. اكتب الاسم `api/index.js` (الشرطة المائلة تنشئ المجلد) والصق الكود، ثم Commit. كرّر لـ `vercel.json` و`package.json`. وإن كانت الملفات القديمة (server.js) موجودة فاحذفها.
2. Vercel → المشروع → Settings → Environment Variables، أضف: `ADMIN_PASSWORD` و`SESSION_SECRET` (طويلان وعشوائيان) و`ALLOWED_ORIGINS` وبيانات X وفيسبوك كما في `.env.example`.
3. Vercel → Storage/Marketplace → أضف **Upstash Redis** واربطه بالمشروع (للجدولة ومنع التكرار). تُضاف متغيراته تلقائيًا.
4. Deployments → آخر نشر → Redeploy (ضروري بعد أي تغيير في المتغيرات).
5. اختبر في المتصفح: `https://مشروعك.vercel.app/api/health` ← يجب أن ترى `{"ok":true}`. الصفحة الرئيسية `/` ستظل 404 وهذا طبيعي.
6. **الجدولة:** الخطة المجانية في Vercel لا تتيح تشغيلًا كل دقيقة. أنشئ مهمة مجانية في cron-job.org تستدعي `https://مشروعك.vercel.app/api/cron` كل دقيقة، مع ترويسة `Authorization: Bearer قيمة_CRON_SECRET` (وعيّن `CRON_SECRET` في Vercel).
