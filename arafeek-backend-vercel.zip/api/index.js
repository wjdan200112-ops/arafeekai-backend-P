// خادم النشر الاجتماعي لمنصة Vercel — دالة واحدة تدير كل مسارات /api/*
// الأسرار تُقرأ من Environment Variables فقط ولا تظهر في الكود أو الواجهة.
const crypto=require('crypto');
const E=process.env,GV=E.GRAPH_VERSION||'v26.0';
const ORIGINS=(E.ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean);
const RU=E.UPSTASH_REDIS_REST_URL||E.KV_REST_API_URL,RT=E.UPSTASH_REDIS_REST_TOKEN||E.KV_REST_API_TOKEN;
const hasStore=()=>!!(RU&&RT),hasX=()=>['X_API_KEY','X_API_SECRET','X_ACCESS_TOKEN','X_ACCESS_SECRET'].every(k=>E[k]),hasFB=()=>!!(E.FB_PAGE_ID&&E.FB_PAGE_TOKEN);
async function rc(...c){const r=await fetch(RU,{method:'POST',headers:{Authorization:'Bearer '+RT},body:JSON.stringify(c)});const j=await r.json().catch(()=>({}));if(!r.ok||j.error)throw new Error(j.error||'Redis '+r.status);return j.result}
const getJob=async id=>{const v=await rc('HGET','jobs',id);return v?JSON.parse(v):null},putJob=j=>rc('HSET','jobs',j.id,JSON.stringify(j)),allJobs=async()=>((await rc('HVALS','jobs'))||[]).map(x=>JSON.parse(x));
const enc=s=>encodeURIComponent(s).replace(/[!'()*]/g,c=>'%'+c.charCodeAt(0).toString(16).toUpperCase());
const hh=s=>crypto.createHash('sha256').update(s).digest();
const mac=b=>crypto.createHmac('sha256',E.SESSION_SECRET).update(b).digest('base64url');
const sign=p=>{const b=Buffer.from(JSON.stringify(p)).toString('base64url');return b+'.'+mac(b)};
const verify=t=>{try{const[b,s]=t.split('.');if(!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(mac(b))))return false;return JSON.parse(Buffer.from(b,'base64url')).exp>Date.now()}catch{return false}};
// ---- X (OAuth 1.0a) ----
function oauth(method,url,params){const o={oauth_consumer_key:E.X_API_KEY,oauth_nonce:crypto.randomBytes(16).toString('hex'),oauth_signature_method:'HMAC-SHA1',oauth_timestamp:String(Math.floor(Date.now()/1000)),oauth_token:E.X_ACCESS_TOKEN,oauth_version:'1.0'};
 const all={...params,...o},base=[method,enc(url),enc(Object.keys(all).sort().map(k=>enc(k)+'='+enc(all[k])).join('&'))].join('&');
 o.oauth_signature=crypto.createHmac('sha1',enc(E.X_API_SECRET)+'&'+enc(E.X_ACCESS_SECRET)).update(base).digest('base64');
 return 'OAuth '+Object.keys(o).sort().map(k=>enc(k)+'="'+enc(o[k])+'"').join(', ')}
async function xcall(method,url,query={},body){const qs=new URLSearchParams(query).toString();
 const r=await fetch(url+(qs?'?'+qs:''),{method,headers:{Authorization:oauth(method,url,query),'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
 const j=await r.json().catch(()=>({}));return r.ok?{ok:true,j}:{ok:false,err:j.detail||j.title||(j.errors&&j.errors[0]&&j.errors[0].message)||('HTTP '+r.status)}}
const pubX=async(t,l)=>{if(!hasX())return{ok:false,error:'X غير مضبوط على الخادم'};const r=await xcall('POST','https://api.x.com/2/tweets',{},{text:l?t+' '+l:t});
 return r.ok?{ok:true,id:r.j.data.id,url:'https://x.com/i/web/status/'+r.j.data.id}:{ok:false,error:r.err}};
// ---- Facebook Page ----
const fb=(p,o)=>fetch(`https://graph.facebook.com/${GV}/${p}`,o);
const pubFB=async(t,l)=>{if(!hasFB())return{ok:false,error:'Facebook غير مضبوط على الخادم'};const b=new URLSearchParams({message:t,access_token:E.FB_PAGE_TOKEN});if(l)b.set('link',l);
 const r=await fb(E.FB_PAGE_ID+'/feed',{method:'POST',body:b}),j=await r.json().catch(()=>({}));
 return r.ok?{ok:true,id:j.id,url:'https://www.facebook.com/'+j.id}:{ok:false,error:(j.error&&j.error.message)||('HTTP '+r.status)}};
async function run(job){const R={};for(const p of job.platforms)R[p]=await(p==='x'?pubX:pubFB)(job.text,job.link).catch(e=>({ok:false,error:String(e.message||e)}));
 const n=Object.values(R).filter(x=>x.ok).length;job.results=R;job.status=n===job.platforms.length?'published':n?'partial':'failed';return job}
// ---- المعالج ----
module.exports=async(req,res)=>{
 const o=req.headers.origin,cors=o&&ORIGINS.includes(o);
 if(cors){res.setHeader('Access-Control-Allow-Origin',o);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');res.setHeader('Access-Control-Allow-Methods','GET,POST,DELETE,OPTIONS')}
 const send=(c,b)=>{res.statusCode=c;res.setHeader('Content-Type','application/json; charset=utf-8');res.end(JSON.stringify(b))};
 if(req.method==='OPTIONS'){res.statusCode=cors?204:403;return res.end()}
 try{
  const u=new URL(req.url,'http://x'),P=u.pathname.replace(/\/$/,''),B=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{});
  if(P==='/api/health')return send(200,{ok:true});
  const miss=['ADMIN_PASSWORD','SESSION_SECRET'].filter(k=>!E[k]);
  if(miss.length)return send(500,{error:'متغيرات بيئة ناقصة على الخادم: '+miss.join('، ')});
  if(P==='/api/cron'){const k=(req.headers.authorization||'').replace('Bearer ','')||u.searchParams.get('key')||'';
   if(!E.CRON_SECRET||k.length!==E.CRON_SECRET.length||!crypto.timingSafeEqual(Buffer.from(k),Buffer.from(E.CRON_SECRET)))return send(401,{error:'غير مصرح'});
   if(!hasStore())return send(200,{ran:0,note:'Redis غير مضبوط'});
   let n=0;for(const j of(await allJobs()).filter(j=>j.status==='scheduled'&&j.at<=Date.now()).slice(0,5)){j.status='publishing';await putJob(j);await run(j);await putJob(j);n++}return send(200,{ran:n})}
  if(P==='/api/login'&&req.method==='POST'){
   if(hasStore()){const ip=String(req.headers['x-forwarded-for']||'').split(',')[0]||'?',k='rl:'+ip,c=await rc('INCR',k);if(c===1)await rc('EXPIRE',k,900);if(c>5)return send(429,{error:'محاولات كثيرة، حاول بعد 15 دقيقة'})}
   if(!crypto.timingSafeEqual(hh(String(B.password||'')),hh(E.ADMIN_PASSWORD)))return send(401,{error:'كلمة المرور غير صحيحة'});
   return send(200,{token:sign({exp:Date.now()+432e5})})}
  if(!verify((req.headers.authorization||'').replace('Bearer ','')))return send(401,{error:'غير مصرح — سجّل الدخول'});
  if(P==='/api/status'){const out={x:{connected:false,error:'غير مضبوط'},facebook:{connected:false,error:'غير مضبوط'},store:hasStore()};
   if(hasX()){const r=await xcall('GET','https://api.x.com/2/users/me');out.x=r.ok?{connected:true,account:'@'+r.j.data.username}:{connected:false,error:r.err}}
   if(hasFB()){const r=await fb(E.FB_PAGE_ID+'?fields=name&access_token='+enc(E.FB_PAGE_TOKEN)),j=await r.json().catch(()=>({}));out.facebook=r.ok?{connected:true,page:j.name}:{connected:false,error:(j.error&&j.error.message)||('HTTP '+r.status)}}
   return send(200,out)}
  if(P==='/api/posts'){const pl=u.searchParams.get('platform'),n=Math.max(5,Math.min(+u.searchParams.get('limit')||10,50));
   if(pl==='x'){if(!hasX())return send(400,{error:'X غير مضبوط'});const me=await xcall('GET','https://api.x.com/2/users/me');if(!me.ok)return send(502,{error:me.err});
    const r=await xcall('GET',`https://api.x.com/2/users/${me.j.data.id}/tweets`,{max_results:String(n),'tweet.fields':'created_at'});if(!r.ok)return send(502,{error:r.err});
    return send(200,{items:(r.j.data||[]).map(t=>({id:t.id,text:t.text,created:t.created_at,url:'https://x.com/i/web/status/'+t.id}))})}
   if(pl==='facebook'){if(!hasFB())return send(400,{error:'Facebook غير مضبوط'});const r=await fb(`${E.FB_PAGE_ID}/posts?fields=id,message,created_time,permalink_url&limit=${n}&access_token=${enc(E.FB_PAGE_TOKEN)}`),j=await r.json().catch(()=>({}));
    if(!r.ok)return send(502,{error:(j.error&&j.error.message)||('HTTP '+r.status)});return send(200,{items:(j.data||[]).map(p=>({id:p.id,text:p.message||'',created:p.created_time,url:p.permalink_url}))})}
   return send(400,{error:'platform غير صالحة'})}
  if(P==='/api/publish'&&req.method==='POST'){const{id,text,link,platforms,scheduledAt}=B;
   if(!id||!text||!Array.isArray(platforms)||!platforms.length||platforms.some(p=>!['x','facebook'].includes(p)))return send(400,{error:'بيانات ناقصة أو غير صالحة'});
   if(link&&!/^https:\/\//.test(link))return send(400,{error:'الرابط يجب أن يبدأ بـ https://'});
   const job={id:String(id),text:String(text).slice(0,2000),link:link||null,platforms,at:scheduledAt?Date.parse(scheduledAt):0,status:'publishing',results:{}};
   if(job.at&&job.at>Date.now()+3e4){if(!hasStore())return send(400,{error:'الجدولة تتطلب ربط قاعدة Redis (Upstash) بالمشروع'});job.status='scheduled';await putJob(job);return send(200,{scheduled:true,jobId:job.id})}
   if(hasStore()){const old=await getJob(job.id);if(old&&old.status==='published')return send(200,{results:old.results,duplicate:true});await putJob(job)}
   await run(job);if(hasStore())await putJob(job);return send(200,{results:job.results})}
  if(P==='/api/jobs'&&req.method==='GET')return send(200,{items:hasStore()?(await allJobs()).map(j=>({id:j.id,status:j.status,results:j.results})):[]});
  if(P.startsWith('/api/jobs/')&&req.method==='DELETE'){const id=decodeURIComponent(P.slice(10));if(hasStore()){const j=await getJob(id);if(j&&j.status==='scheduled')await rc('HDEL','jobs',id)}return send(200,{ok:true})}
  send(404,{error:'غير موجود'})
 }catch(e){send(500,{error:'خطأ داخلي في الخادم'})}
};
